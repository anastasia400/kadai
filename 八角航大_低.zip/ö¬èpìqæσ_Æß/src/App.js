import ContactForm from "./components/ContactForm";

function App() {
  return(
    <div>
      <div className="container">
        <ContactForm/>
      </div>
    </div>
  );
}

export default App;
